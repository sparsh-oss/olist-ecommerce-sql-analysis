-- ============================================================
-- Olist Brazilian E-Commerce Database Analysis
-- Author: Sparsh Mehta
-- Dataset: https://www.kaggle.com/datasets/olistbr/brazilian-ecommerce
-- ============================================================
-- NOTE: This script is written to be safely re-runnable.
-- DROP TABLE IF EXISTS statements prevent "already exists" errors,
-- and TRUNCATE before each LOAD DATA prevents duplicate-row errors
-- if you re-run the script.
-- ============================================================


-- ============================================================
-- SECTION 1: DATABASE SETUP
-- ============================================================

CREATE DATABASE IF NOT EXISTS olist_ecommerce;
USE olist_ecommerce;


-- ============================================================
-- SECTION 2: TABLE CREATION
-- ============================================================

DROP TABLE IF EXISTS customers;
CREATE TABLE customers (
    customer_id VARCHAR(50) PRIMARY KEY,
    customer_unique_id VARCHAR(50),
    customer_zip_code_prefix VARCHAR(10),
    customer_city VARCHAR(100),
    customer_state VARCHAR(5)
);

DROP TABLE IF EXISTS orders;
CREATE TABLE orders (
    order_id VARCHAR(50) PRIMARY KEY,
    customer_id VARCHAR(50),
    order_status VARCHAR(30),
    order_purchase_timestamp DATETIME,
    order_approved_at DATETIME,
    order_delivered_carrier_date DATETIME,
    order_delivered_customer_date DATETIME,
    order_estimated_delivery_date DATETIME
);

DROP TABLE IF EXISTS order_items;
CREATE TABLE order_items (
    order_id VARCHAR(50),
    order_item_id INT,
    product_id VARCHAR(50),
    seller_id VARCHAR(50),
    shipping_limit_date DATETIME,
    price DECIMAL(10,2),
    freight_value DECIMAL(10,2)
);

DROP TABLE IF EXISTS order_payments;
CREATE TABLE order_payments (
    order_id VARCHAR(50),
    payment_sequential INT,
    payment_type VARCHAR(30),
    payment_installments INT,
    payment_value DECIMAL(10,2)
);

DROP TABLE IF EXISTS order_reviews;
CREATE TABLE order_reviews (
    review_id VARCHAR(50),
    order_id VARCHAR(50),
    review_score INT,
    review_comment_title TEXT,
    review_comment_message TEXT,
    review_creation_date DATETIME,
    review_answer_timestamp DATETIME
);

DROP TABLE IF EXISTS products;
CREATE TABLE products (
    product_id VARCHAR(50) PRIMARY KEY,
    product_category_name VARCHAR(100),
    product_name_lenght INT,
    product_description_lenght INT,
    product_photos_qty INT,
    product_weight_g INT,
    product_length_cm INT,
    product_height_cm INT,
    product_width_cm INT
);

DROP TABLE IF EXISTS sellers;
CREATE TABLE sellers (
    seller_id VARCHAR(50) PRIMARY KEY,
    seller_zip_code_prefix VARCHAR(10),
    seller_city VARCHAR(100),
    seller_state VARCHAR(5)
);

DROP TABLE IF EXISTS geolocation;
CREATE TABLE geolocation (
    geolocation_zip_code_prefix VARCHAR(10),
    geolocation_lat DECIMAL(15,10),
    geolocation_lng DECIMAL(15,10),
    geolocation_city VARCHAR(100),
    geolocation_state VARCHAR(5)
);

DROP TABLE IF EXISTS category_translation;
CREATE TABLE category_translation (
    product_category_name VARCHAR(100),
    product_category_name_english VARCHAR(100)
);


-- ============================================================
-- SECTION 3: DATA IMPORT
-- ============================================================
-- Place all 9 CSV files in MySQL's secure upload directory before
-- running this section. Find your directory with:
--   SHOW VARIABLES LIKE 'secure_file_priv';
-- Update the file paths below to match your own directory.
-- ============================================================

SET SESSION sql_mode = '';  -- relaxes strict mode so malformed rows
                              -- (e.g. embedded newlines in review text)
                              -- are skipped with a warning instead of
                              -- halting the entire import

-- Customers
TRUNCATE TABLE customers;
LOAD DATA INFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/olist_customers_dataset.csv'
INTO TABLE customers
FIELDS TERMINATED BY ',' ENCLOSED BY '"' LINES TERMINATED BY '\n' IGNORE 1 ROWS;

-- Orders (uses variables + NULLIF to convert blank date strings to NULL,
-- since several orders have no delivery date if cancelled/undelivered)
TRUNCATE TABLE orders;
LOAD DATA INFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/olist_orders_dataset.csv'
INTO TABLE orders
FIELDS TERMINATED BY ',' ENCLOSED BY '"' LINES TERMINATED BY '\n' IGNORE 1 ROWS
(order_id, customer_id, order_status, @purchase_ts, @approved_ts, @carrier_ts, @delivered_ts, @estimated_ts)
SET
  order_purchase_timestamp = NULLIF(@purchase_ts, ''),
  order_approved_at = NULLIF(@approved_ts, ''),
  order_delivered_carrier_date = NULLIF(@carrier_ts, ''),
  order_delivered_customer_date = NULLIF(@delivered_ts, ''),
  order_estimated_delivery_date = NULLIF(@estimated_ts, '');

-- Order Items
TRUNCATE TABLE order_items;
LOAD DATA INFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/olist_order_items_dataset.csv'
INTO TABLE order_items
FIELDS TERMINATED BY ',' ENCLOSED BY '"' LINES TERMINATED BY '\n' IGNORE 1 ROWS;

-- Order Payments
TRUNCATE TABLE order_payments;
LOAD DATA INFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/olist_order_payments_dataset.csv'
INTO TABLE order_payments
FIELDS TERMINATED BY ',' ENCLOSED BY '"' LINES TERMINATED BY '\n' IGNORE 1 ROWS;

-- Order Reviews (some review_comment_message values contain embedded
-- newlines, which corrupts row boundaries for ~1 row out of ~99,224 --
-- an acceptable, documented data-quality tradeoff)
TRUNCATE TABLE order_reviews;
LOAD DATA INFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/olist_order_reviews_dataset.csv'
INTO TABLE order_reviews
FIELDS TERMINATED BY ',' ENCLOSED BY '"' LINES TERMINATED BY '\n' IGNORE 1 ROWS;

-- Products
TRUNCATE TABLE products;
LOAD DATA INFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/olist_products_dataset.csv'
INTO TABLE products
FIELDS TERMINATED BY ',' ENCLOSED BY '"' LINES TERMINATED BY '\n' IGNORE 1 ROWS;

-- Sellers
TRUNCATE TABLE sellers;
LOAD DATA INFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/olist_sellers_dataset.csv'
INTO TABLE sellers
FIELDS TERMINATED BY ',' ENCLOSED BY '"' LINES TERMINATED BY '\n' IGNORE 1 ROWS;

-- Category Translation
TRUNCATE TABLE category_translation;
LOAD DATA INFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/product_category_name_translation.csv'
INTO TABLE category_translation
FIELDS TERMINATED BY ',' ENCLOSED BY '"' LINES TERMINATED BY '\n' IGNORE 1 ROWS;

-- Geolocation (largest file, ~1 million rows)
TRUNCATE TABLE geolocation;
LOAD DATA INFILE 'C:/ProgramData/MySQL/MySQL Server 8.0/Uploads/olist_geolocation_dataset.csv'
INTO TABLE geolocation
FIELDS TERMINATED BY ',' ENCLOSED BY '"' LINES TERMINATED BY '\n' IGNORE 1 ROWS;


-- ============================================================
-- SECTION 4: VERIFY ROW COUNTS
-- ============================================================

SELECT 'customers' AS table_name, COUNT(*) AS row_count FROM customers
UNION ALL SELECT 'orders', COUNT(*) FROM orders
UNION ALL SELECT 'order_items', COUNT(*) FROM order_items
UNION ALL SELECT 'order_payments', COUNT(*) FROM order_payments
UNION ALL SELECT 'order_reviews', COUNT(*) FROM order_reviews
UNION ALL SELECT 'products', COUNT(*) FROM products
UNION ALL SELECT 'sellers', COUNT(*) FROM sellers
UNION ALL SELECT 'category_translation', COUNT(*) FROM category_translation
UNION ALL SELECT 'geolocation', COUNT(*) FROM geolocation;


-- ============================================================
-- SECTION 5: ANALYSIS QUERIES
-- ============================================================

-- 5.1: Orders enriched with customer location (basic 2-table JOIN)
SELECT o.order_id, o.order_status, o.order_purchase_timestamp,
       c.customer_city, c.customer_state
FROM orders o
JOIN customers c ON o.customer_id = c.customer_id
LIMIT 10;

-- 5.2: Which state has the most orders? (JOIN + GROUP BY)
SELECT c.customer_state, COUNT(o.order_id) AS total_orders
FROM orders o
JOIN customers c ON o.customer_id = c.customer_id
GROUP BY c.customer_state
ORDER BY total_orders DESC
LIMIT 10;

-- 5.3: Revenue by product category (3-table JOIN)
SELECT ct.product_category_name_english,
       COUNT(oi.order_id) AS total_items_sold,
       ROUND(SUM(oi.price), 2) AS total_revenue
FROM order_items oi
JOIN products p ON oi.product_id = p.product_id
JOIN category_translation ct ON p.product_category_name = ct.product_category_name
GROUP BY ct.product_category_name_english
ORDER BY total_revenue DESC
LIMIT 10;

-- 5.4: Lowest-rated product categories, min. 50 reviews (5-table JOIN + HAVING)
SELECT ct.product_category_name_english,
       COUNT(r.review_id) AS total_reviews,
       ROUND(AVG(r.review_score), 2) AS avg_review_score
FROM order_reviews r
JOIN orders o ON r.order_id = o.order_id
JOIN order_items oi ON o.order_id = oi.order_id
JOIN products p ON oi.product_id = p.product_id
JOIN category_translation ct ON p.product_category_name = ct.product_category_name
GROUP BY ct.product_category_name_english
HAVING total_reviews > 50
ORDER BY avg_review_score ASC
LIMIT 10;

-- 5.5: Rank order prices within each state (window function)
SELECT c.customer_state,
       o.order_id,
       oi.price,
       RANK() OVER (PARTITION BY c.customer_state ORDER BY oi.price DESC) AS price_rank
FROM orders o
JOIN customers c ON o.customer_id = c.customer_id
JOIN order_items oi ON o.order_id = oi.order_id
LIMIT 30;

-- 5.6: Days between repeat orders per customer (LAG window function)
-- NOTE: customer_id is unique PER ORDER in this dataset - the same real
-- person is identified across multiple orders via customer_unique_id.
-- Using customer_id here would incorrectly show zero repeat customers.
SELECT c.customer_unique_id,
       o.order_id,
       o.order_purchase_timestamp,
       LAG(o.order_purchase_timestamp) OVER (PARTITION BY c.customer_unique_id ORDER BY o.order_purchase_timestamp) AS previous_order_date,
       DATEDIFF(o.order_purchase_timestamp, LAG(o.order_purchase_timestamp) OVER (PARTITION BY c.customer_unique_id ORDER BY o.order_purchase_timestamp)) AS days_since_last_order
FROM orders o
JOIN customers c ON o.customer_id = c.customer_id
WHERE c.customer_unique_id IN (
    SELECT c2.customer_unique_id
    FROM orders o2
    JOIN customers c2 ON o2.customer_id = c2.customer_id
    GROUP BY c2.customer_unique_id
    HAVING COUNT(*) > 1
)
ORDER BY c.customer_unique_id, o.order_purchase_timestamp
LIMIT 30;

-- 5.7: Each customer's most recent order only (CTE + ROW_NUMBER)
WITH ranked_orders AS (
    SELECT customer_id, order_id, order_purchase_timestamp,
           ROW_NUMBER() OVER (PARTITION BY customer_id ORDER BY order_purchase_timestamp DESC) AS rn
    FROM orders
)
SELECT customer_id, order_id, order_purchase_timestamp
FROM ranked_orders
WHERE rn = 1
LIMIT 20;

-- 5.8: High-value customers - total spend over 1000 (CTE)
WITH customer_spend AS (
    SELECT o.customer_id, SUM(oi.price) AS total_spent
    FROM orders o
    JOIN order_items oi ON o.order_id = oi.order_id
    GROUP BY o.customer_id
)
SELECT c.customer_city, c.customer_state, cs.total_spent
FROM customer_spend cs
JOIN customers c ON cs.customer_id = c.customer_id
WHERE cs.total_spent > 1000
ORDER BY cs.total_spent DESC
LIMIT 20;

-- 5.9: Price vs. category average (correlated subquery)
SELECT oi.order_id,
       p.product_category_name,
       oi.price,
       (SELECT ROUND(AVG(oi2.price), 2)
        FROM order_items oi2
        JOIN products p2 ON oi2.product_id = p2.product_id
        WHERE p2.product_category_name = p.product_category_name) AS category_avg_price,
       ROUND(oi.price - (SELECT AVG(oi2.price)
        FROM order_items oi2
        JOIN products p2 ON oi2.product_id = p2.product_id
        WHERE p2.product_category_name = p.product_category_name), 2) AS diff_from_avg
FROM order_items oi
JOIN products p ON oi.product_id = p.product_id
LIMIT 20;

-- 5.10: Payment method breakdown
SELECT payment_type,
       COUNT(*) AS total_payments,
       ROUND(AVG(payment_installments), 1) AS avg_installments,
       ROUND(AVG(payment_value), 2) AS avg_payment_value
FROM order_payments
GROUP BY payment_type
ORDER BY total_payments DESC;

-- 5.11: Delivery status per order (CASE WHEN)
SELECT 
    o.order_id,
    o.order_estimated_delivery_date,
    o.order_delivered_customer_date,
    DATEDIFF(o.order_delivered_customer_date, o.order_estimated_delivery_date) AS days_late,
    CASE 
        WHEN o.order_delivered_customer_date > o.order_estimated_delivery_date THEN 'Late'
        WHEN o.order_delivered_customer_date <= o.order_estimated_delivery_date THEN 'On Time'
        ELSE 'Not Delivered'
    END AS delivery_status
FROM orders o
WHERE o.order_status = 'delivered'
LIMIT 30;

-- 5.12: % of orders delivered late
SELECT 
    CASE 
        WHEN order_delivered_customer_date > order_estimated_delivery_date THEN 'Late'
        ELSE 'On Time'
    END AS delivery_status,
    COUNT(*) AS total_orders,
    ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM orders WHERE order_status = 'delivered'), 2) AS percentage
FROM orders
WHERE order_status = 'delivered'
GROUP BY delivery_status;

-- 5.13: Does late delivery correlate with lower review scores?
SELECT 
    CASE 
        WHEN o.order_delivered_customer_date > o.order_estimated_delivery_date THEN 'Late'
        ELSE 'On Time'
    END AS delivery_status,
    COUNT(r.review_id) AS total_reviews,
    ROUND(AVG(r.review_score), 2) AS avg_review_score
FROM orders o
JOIN order_reviews r ON o.order_id = r.order_id
WHERE o.order_status = 'delivered'
GROUP BY delivery_status;
